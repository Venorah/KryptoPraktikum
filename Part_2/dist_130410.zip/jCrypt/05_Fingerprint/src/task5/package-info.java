/**
 * Aufgabe 5: Ihre Implementierung der Hashfunktion von Chaum, van Heijst und
 * Pfitzmann.
 * <p>Folgende Eclipse-Run Configuration ist angelegt:
 * <ul>
 * <li>50 Fingerprint makeparam</li>
 * </ul>
 */

package task5;