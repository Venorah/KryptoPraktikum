/**
 * Aufgabe 4: Ihre Implementierung des ElGamal-Public-Key-Kryptosystems.
 * <p>Folgende Eclipse-Run Configurations sind angelegt:
 * <ul>
 * <li>40 ElGamalCipher makekey</li>
 * <li>41 ElGamalSignature makekey</li>
 * </ul>
 */

package task4;