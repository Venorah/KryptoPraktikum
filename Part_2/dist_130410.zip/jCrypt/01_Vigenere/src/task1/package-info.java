/**
 * Aufgabe 1: Ihre Implementierung der Vigen�re-Chiffre.
 * <p>Folgende Eclipse-Run Configuration ist angelegt:
 * <ul>
 * <li>10 Vigenere makekey</li>
 * </ul>
 */

package task1;