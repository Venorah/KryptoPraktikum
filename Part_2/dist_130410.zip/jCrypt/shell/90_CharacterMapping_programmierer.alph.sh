#!/bin/sh

java \
-cp ../jCrypt/jCrypt.jar \
de.tubs.cs.iti.jcrypt.chiffre.CharacterMapping \
../alphabet/programmierer.alph
