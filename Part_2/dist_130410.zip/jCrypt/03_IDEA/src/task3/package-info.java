/**
 * Aufgabe 3: Ihre Implementierung des International Data Encryption Algorithm
 * (IDEA).
 * <p>Folgende Eclipse-Run Configuration ist angelegt:
 * <ul>
 * <li>30 IDEA makekey</li>
 * </ul>
 */

package task3;