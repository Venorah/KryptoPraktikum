/**
 * Aufgabe 2: Ihre Implementierung der Chiffre mit laufendem Schl�ssel.
 * <p>Folgende Eclipse-Run Configuration ist angelegt:
 * <ul>
 * <li>20 RunningKey makekey</li>
 * </ul>
 */

package task2;